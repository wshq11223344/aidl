package com.dn_alan.myapplication;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.dn_alan.service.DNAIdl;
import com.dn_alan.service.Person;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private DNAIdl dnaIdl;

    private String TAG = MainActivity.class.getSimpleName();

    private TextView textView;

    ScheduledExecutorService scheduledExecutorService;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindService();
        textView = findViewById(R.id.tv);

        scheduledExecutorService = Executors.newScheduledThreadPool(1);

//        scheduledExecutorService.scheduleWithFixedDelay(new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    List<Person> people = dnaIdl.getPersonList();
////                    Log.e(TAG, people.toString());
////                    dnaIdl.delPersonList();
//                } catch (Exception e) {
//
//                }
//
//
//            }
//        }, 0, 2, TimeUnit.SECONDS);

//        new Timer().schedule(new TimerTask() {
//            @Override
//            public void run() {
//
//                try {
//
//                } catch (Exception e) {
//
//                }
//
//
//            }
//        }, 3000, 2000);


    }

    @Override
    protected void onStop() {
        super.onStop();
    }


    private void bindService() {
        Intent intent = new Intent();
        intent.setComponent(new ComponentName("com.dn_alan.service", "com.dn_alan.service.DNAidlService"));
        bindService(intent, conn, Context.BIND_AUTO_CREATE);
    }

    private ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            dnaIdl = DNAIdl.Stub.asInterface(service);

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {


        }

    };

    public void click(View view) {
        try {
            dnaIdl.addPerson(new Person("dn", 10));
//            List<Person> people = dnaIdl.getPersonList();
//            Log.e(TAG, people.toString());
//            dnaIdl.delPersonList();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(conn);

//        scheduledExecutorService.shutdown();
//        Log.e(TAG, scheduledExecutorService.isShutdown() + "");
//        Log.e(TAG, scheduledExecutorService.isTerminated() + "");
    }


    @Override
    protected void onResume() {
        super.onResume();

//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    Thread.sleep(3000);
//
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//                textView = findViewById(R.id.tv);
//                textView.setText("123");
//                textView.requestLayout();
//            }
//        }).start();

//        new Thread() {
//            @Override
//            public void run() {
//                super.run();
//                try {
//                    Thread.sleep(3000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//                TextView view = findViewById(R.id.tv);
//                textView.setText("我在子线程更新");
//                textView.invalidate();;
//            }
//        }.start();
    }
}
