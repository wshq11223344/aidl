package com.dn_alan.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DNAidlService extends Service {
    private List<Person> personArrayList;


    @Override
    public IBinder onBind(Intent intent) {
        personArrayList = new ArrayList<>();

        return iBinder;
    }

    private IBinder iBinder = new DNAIdl.Stub() {

        @Override
        public void addPerson(Person person) throws RemoteException {
            personArrayList.add(person);
            Log.e("========", "addPerson在执行");

        }

        @Override
        public List<Person> getPersonList() throws RemoteException {

            Log.e("========", personArrayList.size() + "");

            return personArrayList;

        }

        @Override
        public void delPersonList() throws RemoteException {
            personArrayList.clear();

            Log.e("========", "delPersonList");

        }
    };


}
